/*
# Team ID:          2401
# Theme:            MazeSolver Bot (MB)
# Author List:      Dibyendu Maity, Ankit Dwibedi, Sankalpa Basak, Snehajit Paul
# Filename:         uart_tx.v
# File Description: This module implements a UART (Universal Asynchronous Receiver-Transmitter) transmitter. It serializes an 8-bit parallel data byte, adds a start bit, a calculated parity bit, and a stop bit.
# Global variables: None
*/

/*
Module UART Transmitter

This module implements a UART transmitter. It serializes an 8-bit parallel data byte,
adds a start bit, a parity bit, and a stop bit for asynchronous serial transmission.

Input:  clk_3125    - 3125 KHz clock (Note: Baud rate timing is derived from this)
        parity_type - even(0)/odd(1) parity type
        tx_start    - signal to start the communication
        data        - 8-bit data line to transmit

Output: tx          - UART Transmission Line
        tx_done     - message transmitted flag

Baudrate : 115200 bps
*/

// module declaration
module uart_tx(
    input clk_3125,
    input parity_type,tx_start,
    input [7:0] data,
    output reg tx, tx_done
);

initial begin
    tx = 1'b1;
    tx_done = 1'b0;
end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE//////////////////
 
 /* Add your logic here */

localparam ST_IDLE = 2'd0; // State: Wait for tx_start signal
localparam ST_SEND = 2'd1; // State: Actively send bits

reg [1:0] state = ST_IDLE; // FSM state register

reg [3:0] bit_index = 4'd0; // Index for bit being sent (0:start, 1-8:data, 9:parity, 10:stop)
reg [5:0] bit_timer = 6'd0; // Timer to count clock cycles per bit (0-26)

reg [7:0] sdata = 8'd0;        // sdata: Latched data byte (bit-reversed)

// parity computed from latched sdata 
wire raw_par  = ^sdata; // raw_par: Raw even parity (XOR of all data bits)
wire spar_calc = raw_par ^ parity_type; // spar_calc: Final parity bit (XOR with parity_type)


wire [7:0] d = { data[0], data[1], data[2], data[3],data[4], data[5], data[6], data[7] }; // d: Bit-reversed data input

always @(posedge clk_3125) begin
    /*
    Purpose:
    ---
    This block implements the main Finite State Machine for the UART transmitter.
    It handles the state transitions from IDLE to SEND, manages the timing
    for each bit (start, data, parity, stop) using the 'bit_timer', and sets the
    serial 'tx' line to the correct value. It also generates the 'tx_done' 
    pulse upon completion.
    */
    case (state)
        ST_IDLE: begin
            tx_done <= 1'b0;
            tx <= 1'b1;

            if (tx_start) begin
                sdata <= d;
                bit_index <= 4'd0;
                bit_timer <= 6'd0;
                tx <= 1'b0;  // Output start bit immediately
                state <= ST_SEND;
            end
        end

        ST_SEND: begin
            // Advance timer first
            if (bit_timer < 6'd26) begin
                bit_timer <= bit_timer + 6'd1;
            end else begin
                // Timer expired, move to next bit
                bit_timer <= 6'd0;

                if (bit_index < 4'd10) begin
                    bit_index <= bit_index + 4'd1;

                    // Output next bit using case (Option C)
                    case (bit_index)
                        4'd0: tx <= sdata[0];    // data bit 0 (after start)
                        4'd1: tx <= sdata[1];
                        4'd2: tx <= sdata[2];
                        4'd3: tx <= sdata[3];
                        4'd4: tx <= sdata[4];
                        4'd5: tx <= sdata[5];
                        4'd6: tx <= sdata[6];
                        4'd7: tx <= sdata[7];
                        4'd8: tx <= spar_calc;   // parity bit (computed)
                        default: tx <= 1'b1;     // stop bit or safety
                    endcase

                end else begin
                    // All bits sent, return to idle
                    state <= ST_IDLE;
                    tx <= 1'b1;
                    bit_index <= 4'd0;
                    bit_timer <= 6'd0;
                end
            end

            
            if (bit_index == 4'd10 && bit_timer == 6'd25)
                tx_done <= 1'b1;
            else
                tx_done <= 1'b0;
        end

        default: begin
            state <= ST_IDLE;
            tx <= 1'b1;
            tx_done <= 1'b0;
            bit_index <= 4'd0;
            bit_timer <= 6'd0;
            sdata <= 8'd0;
        end
    endcase
end

//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE//////////////////

endmodule

